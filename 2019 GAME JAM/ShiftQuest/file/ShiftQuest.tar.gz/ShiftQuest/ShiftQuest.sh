#!/bin/bash

./ShiftQuest

