#!/bin/bash

love Road\ Invaders\ 0.6\ GameShell.love
