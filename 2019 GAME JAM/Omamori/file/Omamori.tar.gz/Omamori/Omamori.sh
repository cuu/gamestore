#!/bin/bash

love Omamori.love
